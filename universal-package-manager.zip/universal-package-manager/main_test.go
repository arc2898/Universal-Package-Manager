package main

import (
	"reflect"
	"testing"
)

func TestParseBulkArgs(t *testing.T) {
	got, err := parseBulkArgs([]string{"install", "apt", "git, vim", "snap", "code"})
	if err != nil {
		t.Fatalf("parseBulkArgs returned error: %v", err)
	}
	want := map[string][]string{
		"apt":  {"git", "vim"},
		"snap": {"code"},
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("parseBulkArgs() = %#v, want %#v", got, want)
	}
}

func TestParseBulkArgsRejectsIncompletePairs(t *testing.T) {
	if _, err := parseBulkArgs([]string{"install", "apt"}); err == nil {
		t.Fatal("expected incomplete pair to fail")
	}
	if _, err := parseBulkArgs([]string{"install", "apt", "git", "snap"}); err == nil {
		t.Fatal("expected trailing manager to fail")
	}
}

func TestParseBulkArgsRejectsEmptyPackage(t *testing.T) {
	if _, err := parseBulkArgs([]string{"remove", "apt", "git,,vim"}); err == nil {
		t.Fatal("expected empty package to fail")
	}
}

func TestNewUPMRegistersAllManagers(t *testing.T) {
	u := NewUPM()
	u.Init()
	managerNames := make(map[string]bool)
	for _, m := range u.managers {
		managerNames[m.Name()] = true
	}
	expected := []string{"apt", "dnf", "pacman", "snap", "flatpak", "rpm", "homebrew", "winget", "chocolatey", "scoop", "cargo", "npm", "pip", "gem"}
	for _, name := range expected {
		if !managerNames[name] {
			t.Errorf("expected manager %s to be registered", name)
		}
	}
}

func TestSearchFallbackWhenNotFound(t *testing.T) {
	u := NewUPM()
	u.Init()

	err := u.Search("nonexistent-package-xyz123")
	if err == nil {
		t.Fatal("expected search to fail when package not found in any manager")
	}
	if !contains(err.Error(), "no package managers detected") {
		t.Fatalf("expected 'no package managers detected' error, got: %v", err)
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && containsStr(s, substr)
}

func containsStr(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
